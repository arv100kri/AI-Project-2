Artificial Intelligence Project 2
====================================
Recognition of Unistroke Gesture Sequences
============================================
Team Members
=============

Member #1: Justin Permar - GT ID:902931271
Member #2: Arvind Krishnaa Jagannathan - GT ID: 902891874

Code Structure
===============

Our code is based on the $1 Unistroke Recognizer codebase: http://depts.washington.edu/aimgroup/proj/dollar/

To be precise, we downloaded and modified the dollar.html and dollar.js from that website (available to us via BSD license). Thus, a diff of our files against
the dollar.html and dollar.js files from the website will output all the code that we developed.

The following routines in dollar.js are our routines:

1. DTWForDistanceSegmentation
3. LearnMatch
4. DynamicTimeWarp
5. FindClosestPoint
6. DTWForDistance
7. optimizeDistance
8. GetStrokesByName
9. GetGestures
10. EuclideanDistanceFunc
11. DrawCorners
12. CopyPointArray
13. CopyArrayPart
14. CopyArrayUntilEnd
15. TranslateUnistroke
16. ResultSorterFunction
17. UniformScaleTo

Additionally, the following methods are not used in our final segmentation routine, and can be considered "construction dust" (but are written by us):

1. multiRecognize
2. strokeSimilarity
3. SegmentationAnalysis
4. MinGestureLength
5. FindAllPossibleMatches
6. FindGestureMatchesInSequence
7. IncrementalSearch
8. flattenResults
9. FindGestures
10. OptimizeWindowsize
11. AddNewResults
12. ThreshholdFilter
13. DTWByStroke
14. DTWSequence
15. DTW
16. ScoreTarget
17. StrokeMatchTest
18. ConcatUnistrokes
19. ClearCanvas
20. DrawStroke
21. DescendingResultSorterFunction
22. CopyResultSeq


Additionally, we modified some functions of the $1 Unistroke Recognizer codebase:

1. AddGesture

How to "execute" our project
=============================

1. The gesture recognizer prototype is simply a HTML file, "dollar.html" which needs to be opened.
2. To train existing gestures or to add new gestures, simply check the "Training" checkbox and draw the unistroke (individual) gesture in the canvas.
3. If the system wrongly "labels" the gesture, you can tell the system what the intended gesture was.
4. To begin the "recognition" phase, simply uncheck the "Training" checkbox and draw any unistroke gesture sequence in the canvas.
5. Once the stroke is completed, the system will indicate which are the gestures that it thinks are part of the input sequence.
6. Compare this with what your intented input sequence.